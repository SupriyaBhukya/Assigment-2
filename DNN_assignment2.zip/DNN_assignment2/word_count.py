input_file = open('/input.txt','r')
count = dict()
outputvalue = input_file.read()
words = outputvalue.split()
for word in words:
   if word in count:
     count[word]+=1
   else:
     count[word]=1
print(count)
f = open('output.txt','w')
f.write(outputvalue)
for key, value in count.items():
  f.write(f"{key}:{value}\n")
f.close()
