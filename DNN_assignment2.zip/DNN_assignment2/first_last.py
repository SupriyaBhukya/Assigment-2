#printing first name and last name

def fullname():
  first_name = input("enter the first name")
  last_name = input("enter the last name")
  return "full name is:"+first_name+" "+last_name

if __name__ == "__main__":
  print(fullname())
