#nested loop

b=list(map(int, input().split()))
for ele in b:
    print(ele*2.5, end=' ')
