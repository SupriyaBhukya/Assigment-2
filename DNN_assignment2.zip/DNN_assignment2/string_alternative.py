#printing alternative characters

def string_alternative():
  input_value = input("enter the string")
  print(input_value[::2])
if __name__ == "__main__":
  string_alternative()
