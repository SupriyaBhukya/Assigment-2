#using list comprehensions

input_value1=list(map(int, input().split()))
output1=[ele*2.5 for ele in input_value1]
print(output1)
